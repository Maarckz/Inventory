document.addEventListener('DOMContentLoaded', function() {
    // Gestão de Alertas (Toasts)
    document.querySelectorAll('.alert-close').forEach(button => {
        button.addEventListener('click', function() {
            const alert = this.parentElement;
            alert.style.opacity = '0';
            alert.style.transform = 'translateX(100px)';
            setTimeout(() => alert.remove(), 400);
        });
    });

    // Auto-remover alertas após 5 segundos
    document.querySelectorAll('.alert').forEach(alert => {
        setTimeout(() => {
            if (alert.parentElement) {
                alert.style.opacity = '0';
                alert.style.transform = 'translateX(100px)';
                setTimeout(() => alert.remove(), 400);
            }
        }, 5000);
    });

    // Animação de tabelas
    const tableRows = document.querySelectorAll('.machine-table tbody tr');
    tableRows.forEach((row, i) => {
        row.style.animationDelay = (i * 0.07) + 's';
    });

    // Clique nas linhas da tabela
    document.querySelectorAll('.machine-row').forEach(row => {
        row.style.cursor = 'pointer';
        row.addEventListener('click', function() {
            window.location.href = this.getAttribute('data-href');
        });
    });

    // Fechar modais com ESC
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            document.querySelectorAll('.modal.active').forEach(m => {
                m.classList.remove('active');
            });
        }
    });
});

// Função Global de Toast
function showToast(message, category = 'success') {
    const container = document.querySelector('.toast-container');
    if (!container) return;

    const alert = document.createElement('div');
    alert.className = `alert alert-${category} toast-show`;
    alert.innerHTML = `
        <span>${message}</span>
        <button class="alert-close">
            <i class="fas fa-times"></i>
        </button>
    `;

    container.appendChild(alert);

    // Evento de fechar manual
    alert.querySelector('.alert-close').addEventListener('click', () => {
        alert.style.opacity = '0';
        alert.style.transform = 'translateX(100px)';
        setTimeout(() => alert.remove(), 400);
    });

    // Auto-remover
    setTimeout(() => {
        if (alert.parentElement) {
            alert.style.opacity = '0';
            alert.style.transform = 'translateX(100px)';
            setTimeout(() => alert.remove(), 400);
        }
    }, 5000);
}