###########################
## IMPORTAR  BIBLIOTECAS ##
###########################
import os
import time
import pyotp
import fcntl
import qrcode
import base64
import struct
import socket
import logging
import bcrypt
import ipaddress
from io import BytesIO
from datetime import datetime
from dotenv import load_dotenv
from flask_session import Session
from collections import defaultdict
from utils.language import LANGUAGES
from datetime import datetime, timedelta
from utils.pdf_export import generate_pdf_report
from logging.handlers import RotatingFileHandler
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, make_response
from flask_sqlalchemy import SQLAlchemy
from flask_apscheduler import APScheduler
from asgiref.wsgi import WsgiToAsgi
from functools import wraps
from models import db, User, HostInventory, Group, SystemSetting
from utils.collector import sync_wazuh_data


#############################################
## IMPORTAR  VARIAVEIS DE AMBIENTE DO .ENV ##
#############################################
load_dotenv()


############################
## CONFIGURACOES INICIAIS ##
############################

#CONFIGURACOES DO FLASK
app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY')
app.config['STATIC_FOLDER'] = 'static'

app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SECURE=True,
    SESSION_COOKIE_SAMESITE='Strict',
    PERMANENT_SESSION_LIFETIME=900,
    MAX_CONTENT_LENGTH=1024 * 1024,
    SESSION_SALT=os.getenv('SESSION_SALT', 'default_salt_value')
)

app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_FILE_DIR'] = os.path.join(os.getenv('LOG_DIR'), 'flask_sessions')
app.config['SESSION_PERMANENT'] = True
Session(app)

# --- Configurações do PostgreSQL ---
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL', 'postgresql://postgres:suasenha@localhost/inventory_db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Inicializa o Banco
db.init_app(app)

# --- Configuração do Automatizador (Scheduler) ---
scheduler = APScheduler()
scheduler.init_app(app)
scheduler.start()

def scheduled_sync():
    with app.app_context():
        sync_wazuh_data(app)

# --- Criando o Banco e Configurações Iniciais ---
with app.app_context():
    db.create_all()
    
    # 1. Carregar/Configurar Intervalo de Sincronização
    sync_setting = SystemSetting.query.filter_by(key='sync_interval').first()
    if not sync_setting:
        sync_setting = SystemSetting(key='sync_interval', value={'seconds': 3600})
        db.session.add(sync_setting)
        db.session.commit()
    
    interval_seconds = sync_setting.value.get('seconds', 3600)
    
    # Remove job se existir para recriar com o intervalo correto
    if scheduler.get_job('wazuh_sync'):
        scheduler.remove_job('wazuh_sync')
        
    scheduler.add_job(id='wazuh_sync', func=scheduled_sync, trigger='interval', seconds=interval_seconds)
    app.logger.info(f"Sincronização agendada para cada {interval_seconds} segundos.")

    # 2. Cria o admin padrão se não existir nenhum usuário
    if not User.query.first():
        hashed = bcrypt.hashpw('Meuadmin123'.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        admin_user = User(username='admin', password_hash=hashed, role='admin')
        db.session.add(admin_user)
        db.session.commit()
        app.logger.info("Usuário padrão criado (admin / Meuadmin123)")

INVENTORY_DIR = os.getenv('INVENTORY_DIR')
GROUPS_DIR = os.getenv('GROUPS_DIR')
LOG_DIR = os.getenv('LOG_DIR')
AUTH_FILE = os.getenv('AUTH_FILE')
SSL_CERT = os.getenv('SSL_CERT_PATH')
SSL_KEY = os.getenv('SSL_KEY_PATH')
USE_HTTPS = os.getenv('USE_HTTPS').lower() == 'true'
ALLOWED_IP_RANGES = os.getenv('ALLOWED_IP_RANGES').split(',')

os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(app.config['SESSION_FILE_DIR'], exist_ok=True)

ssl_context = None
if USE_HTTPS:
    if os.path.exists(SSL_CERT) and os.path.exists(SSL_KEY):
        ssl_context = (SSL_CERT, SSL_KEY)
    else:
        app.logger.warning("Certificado SSL não encontrado. Executando HTTP")

server_ips = {'127.0.0.1', 'localhost'}
try:
    for iface in os.listdir('/sys/class/net'):
        try:
            with open(f'/sys/class/net/{iface}/operstate') as f:
                if f.read().strip() != 'up':
                    continue
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                ip = socket.inet_ntoa(fcntl.ioctl(
                    s.fileno(),
                    0x8915,  # SIOCGIFADDR
                    struct.pack('256s', iface[:15].encode('utf-8'))
                )[20:24])
                if ip and ip != '127.0.0.1':
                    server_ips.add(ip)
            except OSError:
                continue
            finally:
                s.close()
        except Exception:
            continue
except Exception as e:
    app.logger.error(f"Erro ao obter IPs do servidor: {str(e)}")
    
SERVER_IPS = list(server_ips)

compiled_allowed_networks = []
if ALLOWED_IP_RANGES and any(ALLOWED_IP_RANGES):
    for ip_range in ALLOWED_IP_RANGES:
        if ip_range.strip():
            try:
                network = ipaddress.ip_network(ip_range.strip(), strict=False)
                compiled_allowed_networks.append(network)
            except ValueError as e:
                app.logger.error(f"Rede inválida {ip_range}: {str(e)}")

def setup_logging():
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    
    info_handler = RotatingFileHandler(os.path.join(LOG_DIR, 'info.log'), maxBytes=10*1024*1024, backupCount=5)
    info_handler.setLevel(logging.INFO)
    info_handler.setFormatter(formatter)
    
    warning_handler = RotatingFileHandler(os.path.join(LOG_DIR, 'warning.log'), maxBytes=10*1024*1024, backupCount=5)
    warning_handler.setLevel(logging.WARNING)
    warning_handler.setFormatter(formatter)
    
    error_handler = RotatingFileHandler(os.path.join(LOG_DIR, 'error.log'), maxBytes=10*1024*1024, backupCount=5)
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(formatter)
    
    security_handler = RotatingFileHandler(os.path.join(LOG_DIR, 'security.log'), maxBytes=10*1024*1024, backupCount=5)
    security_handler.setLevel(logging.INFO)
    security_handler.setFormatter(logging.Formatter('%(asctime)s - SECURITY - %(message)s'))
    
    app.logger.setLevel(logging.DEBUG)
    app.logger.addHandler(info_handler)
    app.logger.addHandler(warning_handler)
    app.logger.addHandler(error_handler)
    
    security_logger = logging.getLogger('security')
    security_logger.setLevel(logging.INFO)
    security_logger.addHandler(security_handler)
    security_logger.propagate = False
    
    audit_logger = logging.getLogger('audit')
    audit_handler = RotatingFileHandler(os.path.join(LOG_DIR, 'audit.log'), maxBytes=10*1024*1024, backupCount=5)
    audit_handler.setFormatter(logging.Formatter('%(asctime)s - %(message)s'))
    audit_logger.addHandler(audit_handler)
    audit_logger.setLevel(logging.INFO)
    audit_logger.propagate = False

setup_logging()

security_logger = logging.getLogger('security')
audit_logger = logging.getLogger('audit')

# No mais carregamento de JSONs locais, tudo via DB

# Configuração de Cache
app.MACHINES_CACHE = {'data': None, 'last_update': 0}
app.STATS_CACHE = {'data': None, 'last_update': 0}
CACHE_TIMEOUT = 40

def get_cached_machines():
    current_time = time.time()
    if not app.MACHINES_CACHE['data'] or (current_time - app.MACHINES_CACHE['last_update']) > CACHE_TIMEOUT:
        app.MACHINES_CACHE['data'] = get_all_machines()
        app.MACHINES_CACHE['last_update'] = current_time
    return app.MACHINES_CACHE['data']

def get_cached_stats():
    current_time = time.time()
    if not app.STATS_CACHE['data'] or (current_time - app.STATS_CACHE['last_update']) > CACHE_TIMEOUT:
        machines = get_cached_machines()
        app.STATS_CACHE['data'] = get_machine_stats(machines)
        app.STATS_CACHE['last_update'] = current_time
    return app.STATS_CACHE['data']


def formatar_data(data_iso):
    try:
        data = datetime.fromisoformat(data_iso)
        return data.strftime('%d/%m/%Y %H:%M')
    except (ValueError, TypeError):
        return data_iso

app.jinja_env.filters['formatar_data'] = formatar_data

def get_ram_range(ram_gb):
    ranges = [
        (2, "0-2GB"), (4, "3-4GB"), (8, "5-8GB"),
        (16, "9-16GB"), (32, "17-32GB"), (64, "33-64GB")
    ]
    for limit, label in ranges:
        if ram_gb <= limit:
            return label
    return "64+GB" if ram_gb > 0 else "Unknown"

def get_machine_stats(machines):
    # Dicionários padrão para evitar confusão de tipos do linter
    os_counts = {}
    cpu_counts = {}
    ram_counts = {}
    status_counts = {'Ativo': 0, 'Inativo': 0}
    port_counts = {}
    proc_counts = {}
    software_counts = {}
    total = 0
    
    for machine in machines:
        # OS
        name = machine.get('os_name', 'Unknown')
        os_counts[name] = os_counts.get(name, 0) + 1
        
        # CPU
        cpu = machine.get('cpu_name', 'Unknown')
        cpu_counts[cpu] = cpu_counts.get(cpu, 0) + 1
        
        # RAM
        ram_gb = machine.get('ram_gb', 0)
        range_key = get_ram_range(ram_gb)
        ram_counts[range_key] = ram_counts.get(range_key, 0) + 1
        
        # Status
        status = machine.get('device_status', 'Inativo')
        status_counts[status] = status_counts.get(status, 0) + 1
        
        # Ports
        for port in machine.get('ports', []):
            local = port.get('local', {})
            ip = local.get('ip', '')
            if ip and ('.' in ip or ':' in ip):
                p_num = str(local.get('port', 'Unknown'))
                if p_num not in ('N/A', 'Unknown'):
                    port_counts[p_num] = port_counts.get(p_num, 0) + 1
        
        # Processes
        for proc in machine.get('processes', []):
            p_name = proc.get('name', 'Unknown')
            if p_name not in ('N/A', 'Unknown'):
                proc_counts[p_name] = proc_counts.get(p_name, 0) + 1

        # Software
        for pkg in machine.get('packages', []):
            pkg_name = pkg.get('name', 'Unknown')
            if pkg_name not in ('N/A', 'Unknown'):
                software_counts[pkg_name] = software_counts.get(pkg_name, 0) + 1
        
        total += 1
    
    return {
        'os': os_counts,
        'cpu': cpu_counts,
        'ram': ram_counts,
        'status': status_counts,
        'ports': port_counts,
        'processes': proc_counts,
        'software': software_counts,
        'total': total
    }
        

from utils.machine_handler import process_machine_data, get_machine_fallback

def get_all_machines():
    try:
        # Carrega apenas máquinas não-legadas (sincronizadas) para o Dashboard principal
        hosts = HostInventory.query.filter_by(is_legacy=False).all()
        machines_list = []
        processed_count = 0
        for h in hosts:
            try:
                processed = process_machine_data(h.data)
                if processed:
                    machines_list.append(processed)
                    processed_count += 1
            except Exception as e:
                app.logger.error(f"Erro ao processar máquina: {e}")
        
        app.logger.info(f"[Dashboard] Carregados {len(machines_list)} hosts do banco de dados para o cache.")
        return machines_list
    except Exception as e:
        app.logger.error(f"Erro fatal ao buscar máquinas do banco: {e}")
        return []

def get_cached_machines():
    # Inicializa se não existir
    if not hasattr(app, 'MACHINES_CACHE'):
        app.MACHINES_CACHE = {'data': None, 'last_update': 0}
        
    if app.MACHINES_CACHE['data'] is None:
        # Primeira carga
        machines = get_all_machines()
        app.MACHINES_CACHE['data'] = machines
        app.MACHINES_CACHE['last_update'] = time.time()
        return machines
    
    return app.MACHINES_CACHE['data']

def verify_password(stored_hash, password):
    try:
        if stored_hash.startswith('$2b$'):
            return bcrypt.checkpw(password.encode('utf-8'), stored_hash.encode('utf-8'))
        return False
    except Exception as e:
        app.logger.error(f"Erro na verificação de senha: {str(e)}")
        return False

def is_ip_allowed(ip):
    if not compiled_allowed_networks:
        return True 
    
    if ip in SERVER_IPS:
        return True
        
    try:
        ip_addr = ipaddress.ip_address(ip)
        for network in compiled_allowed_networks:
            if ip_addr in network:
                return True
    except ValueError as e:
        app.logger.error(f"Erro ao verificar IP {ip}: {str(e)}")
    
    return False

# --- Decoradores de Controle de Acesso (RBAC) ---
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'username' not in session or session.get('role') != 'admin':
            flash("Acesso negado. Apenas administradores.", "danger")
            return redirect(url_for('dashboard'))
        return f(*args, **kwargs)
    return decorated_function

@app.before_request
def check_access():
    client_ip = request.remote_addr
    #user_agent = request.headers.get('User-Agent', 'Desconhecido')
    
    if 'username' in session:
        username = session['username']
    else:
        username = 'Não autenticado'
    
    audit_logger.info(f"ACESSO - IP: {client_ip}, Usuário: {username}, Endpoint: {request.endpoint}, Método: {request.method}")
    
    if not request.path.startswith('/static'):
        if not is_ip_allowed(client_ip):
            security_logger.warning(f"ACESSO BLOQUEADO - IP não permitido: {client_ip}, Usuário: {username}, Endpoint: {request.endpoint}")
            return render_template('error.html', error_code=403, message="Acesso não permitido a partir do seu endereço IP"), 403

# Rotas
@app.route('/')
@app.route('/dashboard')
@login_required
def dashboard():
    
    if 'username' not in session:
        return redirect(url_for('login'))
    
    stats = get_cached_stats()
    
    return render_template('dashboard.html', 
                         stats=stats,
                         active_count=stats['status']['Ativo'],
                         inactive_count=stats['status']['Inativo'])

@app.route('/get_chart_data')
def get_chart_data():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    stats = get_cached_stats()
    machines = get_cached_machines()
    try:
        app.logger.debug(f"[Dashboard] Iniciando formatação de dados para {len(machines)} máquinas.")
        
        common_services = {
            '22': 'SSH', '80': 'HTTP', '443': 'HTTPS', '21': 'FTP', '53': 'DNS',
            '3306': 'MySQL', '5432': 'PostgreSQL', '27017': 'MongoDB', '6379': 'Redis'
        }
        
        # Portas
        port_details = defaultdict(lambda: {'count': 0, 'protocol': 'tcp'})
        for machine in machines:
            try:
                for port in machine.get('ports', []):
                    if isinstance(port, dict):
                        port_num = str(port.get('local', {}).get('port', ''))
                        if port_num and port_num != 'N/A':
                            port_details[port_num]['count'] += 1
                            if port.get('protocol', '').lower() == 'udp':
                                port_details[port_num]['protocol'] = 'udp'
            except Exception as e:
                app.logger.error(f"Erro ao processar portas de uma máquina: {e}")
        
        sorted_ports = sorted(port_details.items(), key=lambda x: x[1]['count'], reverse=True)[:10]
        port_labels = []
        port_data = []
        port_protocols = []
        for port, details in sorted_ports:
            service = common_services.get(port, '')
            label = f"{service} - {port}/{details['protocol'].upper()}" if service else f"{port}/{details['protocol'].upper()}"
            port_labels.append(label)
            port_data.append(details['count'])
            port_protocols.append(details['protocol'])

        # Processos
        sorted_processes = sorted(stats.get('processes', {}).items(), key=lambda x: x[1], reverse=True)[:10]
        process_labels = [proc for proc, count in sorted_processes]
        process_data = [count for proc, count in sorted_processes]
        
        # Grupos
        groups_data = []
        try:
            # Filtra grupos ativos (não legados) para as estatísticas
            groups_objs = Group.query.filter_by(is_legacy=False).all()
            groups_data = [g.data for g in groups_objs if g.data]
        except Exception:
            pass

        # Timeline
        timeline_data = {'dates': [], 'active': [], 'inactive': []}
        today = datetime.now().date()
        for i in range(6, -1, -1):
            date = today - timedelta(days=i)
            timeline_data['dates'].append(date.strftime('%d/%m'))
            a, inat = 0, 0
            for machine in machines:
                ls = machine.get('last_seen')
                if ls and ls != 'N/A':
                    try:
                        m_date = datetime.fromisoformat(ls).date() if isinstance(ls, str) else ls.date()
                        if m_date == date:
                            if machine.get('device_status') == 'Ativo': a += 1
                            else: inat += 1
                    except Exception: continue
            timeline_data['active'].append(a)
            timeline_data['inactive'].append(inat)

        # Resumo final
        response_data = {
            'os_labels': list(stats.get('os', {}).keys()),
            'os_data': list(stats.get('os', {}).values()),
            'cpu_labels': list(stats.get('cpu', {}).keys()),
            'cpu_data': list(stats.get('cpu', {}).values()),
            'ram_labels': list(stats.get('ram', {}).keys()),
            'ram_data': list(stats.get('ram', {}).values()),
            'port_labels': port_labels,
            'port_data': port_data,
            'port_protocols': port_protocols,
            'process_labels': process_labels,
            'process_data': process_data,
            'active_count': stats.get('status', {}).get('Ativo', 0),
            'inactive_count': stats.get('status', {}).get('Inativo', 0),
            'last_update': [m.get('last_seen', 0) for m in machines[:5]],
            'groups': groups_data,
            'timeline_dates': timeline_data['dates'],
            'timeline_active': timeline_data['active'],
            'timeline_inactive': timeline_data['inactive'],
            'recent_machines': [
                {'name': m.get('hostname', 'N/A'), 'os': m.get('os_name', 'N/A'), 'status': translate(m.get('device_status', 'N/A'))}
                for m in sorted(machines, key=lambda x: str(x.get('last_seen', '')), reverse=True)[:5]
            ]
        }
        return jsonify(response_data)
    except Exception as e:
        app.logger.error(f"Erro crítico em /get_chart_data: {e}")
        return jsonify({'error': str(e), 'os_labels': [], 'os_data': []}), 500

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'username' in session:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username', '')[:50]
        password = request.form.get('password', '')[:100]
        client_ip = request.remote_addr
        
        if not username or not password:
            flash('Preencha todos os campos', 'error')
            return render_template('login.html')
        
        user = User.query.filter_by(username=username).first()
        
        if user and bcrypt.checkpw(password.encode('utf-8'), user.password_hash.encode('utf-8')):
            if user.mfa_enabled:
                session['mfa_username'] = username
                session['mfa_expire'] = time.time() + 300 # 5 min
                return redirect(url_for('verify_mfa'))
            
            session['username'] = username
            session['role'] = user.role
            session['user_id'] = user.id
            session['user_ip'] = client_ip  
            session['user_agent'] = request.headers.get('User-Agent', '') 
            session['login_time'] = time.time() 
            
            security_logger.info(f"LOGIN BEM-SUCEDIDO - Usuário: {username}, IP: {client_ip}")
            return redirect(url_for('dashboard'))
        else:
            security_logger.warning(f"TENTATIVA DE LOGIN FALHA - Usuário: {username}, IP: {client_ip}")
            flash('Credenciais inválidas', 'error')
    
    return render_template('login.html')

@app.route('/verify_mfa', methods=['GET', 'POST'])
def verify_mfa():
    if 'mfa_username' not in session or time.time() > session.get('mfa_expire', 0):
        flash('Sessão expirada. Faça login novamente', 'error')
        session.pop('mfa_username', None)
        return redirect(url_for('login'))
    
    username = session['mfa_username']
    
    if request.method == 'POST':
        code = request.form.get('code', '')
        user = User.query.filter_by(username=username).first()
        
        if user and user.mfa_enabled and user.mfa_secret:
            totp = pyotp.TOTP(user.mfa_secret)
            if totp.verify(code, valid_window=1):
                # Mantém a limpeza da sessão temporária
                session.pop('mfa_username', None)
                
                # Define os dados da sessão definitiva
                session['username'] = username
                session['role'] = user.role  # <--- ESSA LINHA É NECESSÁRIA PARA O ADMIN_REQUIRED
                
                # Mantém todas as suas funcionalidades de auditoria e segurança
                session['user_ip'] = request.remote_addr  
                session['user_agent'] = request.headers.get('User-Agent', '') 
                session['login_time'] = time.time() 
                
                security_logger.info(f"LOGIN MFA BEM-SUCEDIDO - Usuário: {username}, IP: {request.remote_addr}")
                return redirect(url_for('dashboard'))
        
        flash('Código MFA inválido', 'error')
    
    return render_template('verify_mfa.html')
@app.route('/logout')
def logout():
    username = session.get('username', 'Desconhecido')
    client_ip = request.remote_addr
    
    security_logger.info(f"LOGOUT - Usuário: {username}, IP: {client_ip}")
    
    session.clear()
    return redirect(url_for('login'))

# --- Rotas do Painel de Administração ---

@app.route('/admin/users')
@admin_required
def manage_users():
    users = User.query.all()
    return render_template('admin_users.html', users=users)

# A sincronização agora é feita via AJAX em /settings/sync_now

@app.route('/admin/users/add', methods=['POST'])
@admin_required
def add_user():
    username = request.form.get('username')
    password = request.form.get('password')
    confirm_password = request.form.get('confirm_password')
    role = request.form.get('role', 'user')
    
    if not username or not password:
        flash("Usuário e senha são obrigatórios.", "danger")
        return redirect(url_for('settings'))
    
    if password != confirm_password:
        flash("As senhas não coincidem.", "danger")
        return redirect(url_for('settings'))
    
    if User.query.filter_by(username=username).first():
        flash("Usuário já existe.", "danger")
        return redirect(url_for('settings'))
    
    hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    novo_usuario = User(username=username, password_hash=hashed, role=role)
    db.session.add(novo_usuario)
    db.session.commit()
    flash(f"Usuário {username} criado com sucesso.", "success")
    return redirect(url_for('settings'))

@app.route('/admin/users/delete/<int:user_id>', methods=['POST'])
@admin_required
def delete_user(user_id):
    user = User.query.get_or_404(user_id)
    if user.username == 'admin':
        flash("Não é possível remover o administrador principal.", "danger")
    else:
        db.session.delete(user)
        db.session.commit()
        flash(f"Usuário {user.username} removido com sucesso.", "success")
    return redirect(url_for('settings'))

@app.route('/settings/update_sync', methods=['POST'])
@admin_required
def update_sync():
    data = request.get_json()
    seconds = data.get('seconds')
    if seconds is None:
        return jsonify(success=False, error="Intervalo inválido"), 400
    
    sync_setting = SystemSetting.query.filter_by(key='sync_interval').first()
    if not sync_setting:
        sync_setting = SystemSetting(key='sync_interval', value={'seconds': int(seconds)})
        db.session.add(sync_setting)
    else:
        sync_setting.value = {'seconds': int(seconds)}
    
    db.session.commit()
    
    # Atualiza o Scheduler
    if scheduler.get_job('wazuh_sync'):
        scheduler.remove_job('wazuh_sync')
    
    scheduler.add_job(id='wazuh_sync', func=scheduled_sync, trigger='interval', seconds=int(seconds))
    
    return jsonify(success=True)

@app.route('/settings/sync_now', methods=['POST'])
@admin_required
def sync_now():
    try:
        import threading
        # Chama em background para não travar o request
        threading.Thread(target=sync_wazuh_data, args=(app,)).start()
        # Invalida o cache para forçar recarregamento do dashboard
        app.MACHINES_CACHE['data'] = None
        app.STATS_CACHE['data'] = None
        
        app.logger.info("Sincronização manual disparada pelo administrador.")
        return jsonify(success=True)
    except Exception as e:
        app.logger.error(f"Erro ao disparar sincronização manual: {e}")
        return jsonify(success=False, error=str(e))

@app.route('/settings/change_password', methods=['POST'])
@login_required
def change_password():
    current_password = request.form.get('current_password')
    new_password = request.form.get('new_password')
    confirm_new_password = request.form.get('confirm_new_password')
    
    if new_password != confirm_new_password:
        flash("A nova senha e a confirmação não coincidem.", "danger")
        return redirect(url_for('settings'))
    
    user = User.query.filter_by(username=session['username']).first()
    if user and bcrypt.checkpw(current_password.encode('utf-8'), user.password_hash.encode('utf-8')):
        user.password_hash = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
        db.session.commit()
        flash("Senha alterada com sucesso.", "success")
    else:
        flash("Senha atual incorreta.", "danger")
    return redirect(url_for('settings'))

@app.route('/painel')
@login_required
def painel():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    page = request.args.get('page', 1, type=int)
    per_page = 50
    
    machines = get_cached_machines()
    total_machines = len(machines)
    
    start_idx = (page - 1) * per_page
    end_idx = start_idx + per_page
    paginated_machines = machines[start_idx:end_idx]
    
    return render_template('painel.html', 
                          machines=paginated_machines,
                          page=page,
                          per_page=per_page,
                          total=total_machines)

@app.route('/search')
@login_required
def search():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    query = request.args.get('query', '')[:100].strip().lower()
    machines = get_cached_machines()
    results = []
    added_hostnames = set()

    if not query:
        return render_template('search.html', results=machines, query="")

    # --- LÓGICA ESPECIAL PARA RAM (RANGE E VALORES) ---
    if query.startswith('ram_gb:'):
        ram_query = query.replace('ram_gb:', '').replace('gb', '').strip()
        
        ram_ranges = {
            "0-2": (0, 2),
            "3-4": (3, 4),
            "5-6": (5, 6),
            "7-8": (7, 8),
            "9-12": (9, 12),
            "13-16": (13, 16),
            "17-24": (17, 24),
            "25-32": (25, 32),
            "33-64": (33, 64)
        }

        for m in machines:
            try:
                ram_val = float(m.get('ram_gb', 0))
                
                if "-" in ram_query:
                    if ram_query in ram_ranges:
                        min_r, max_r = ram_ranges[ram_query]
                    else:
                        parts = ram_query.split('-')
                        min_r, max_r = float(parts[0]), float(parts[1])
                    
                    if min_r <= ram_val <= max_r:
                        results.append(m)
                
                elif ram_query.startswith('>'):
                    limit = float(ram_query.replace('>', ''))
                    if ram_val > limit:
                        results.append(m)
                
                elif ram_query.startswith('<'):
                    limit = float(ram_query.replace('<', ''))
                    if ram_val < limit:
                        results.append(m)

                else:
                    if float(ram_query) == ram_val:
                        results.append(m)
            except (ValueError, IndexError):
                continue
        
        return render_template('search.html', results=results, query=query)

    # --- LÓGICA PARA TAGS (ports:, agent_info:, inventory:xxx:) ---
    if ':' in query:
        tag_parts = query.split(':')
        tag = tag_parts[0].strip()
        
        search_term = tag_parts[-1].strip()
        sub_tag = tag_parts[1].strip() if len(tag_parts) > 2 else None
        
        for m in machines:
            hostname = m.get('hostname', '')
            if hostname in added_hostnames: continue
            found = False
            
            if tag in ['groups', 'group' ]:
                candidate_groups = []
                
                if m.get('groups'):
                    candidate_groups.extend(m['groups'] if isinstance(m['groups'], list) else [m['groups']])
                
                agent_info = m.get('agent_info', {})
                if isinstance(agent_info, dict):
                    raw_g = agent_info.get('group')
                    if raw_g:
                        candidate_groups.extend(raw_g if isinstance(raw_g, list) else [raw_g])

                for g in candidate_groups:
                    if search_term in str(g).lower():
                        found = True
                        break
            
            
            if tag == 'ports':
                for port in m.get('ports', []):
                    if search_term == str(port.get('local', {}).get('port', '')):
                        found = True; break
            
            elif tag == 'agent_info':
                if (search_term in m.get('hostname', '').lower() or
                    search_term in m.get('ip_address', '').lower() or
                    search_term in m.get('id', '').lower() or
                    search_term in m.get('group', '').lower()):
                    found = True
                elif sub_tag == 'status':
                    status_map = {'active': 'ativo', 'disconnected': 'inativo'}
                    if status_map.get(search_term) == m.get('device_status', '').lower():
                        found = True
            
            elif tag == 'inventory' and sub_tag:
                if sub_tag == 'os':
                    if any(search_term in str(m.get(k, '')).lower() for k in ['os_name', 'os_version', 'os_architecture', 'os_kernel', 'os_platform']):
                        found = True
                elif sub_tag == 'hardware':
                    if (search_term in m.get('cpu_name', '').lower() or
                        search_term in str(m.get('cpu_cores', '')) or
                        search_term in m.get('board_serial', '').lower()):
                        found = True
                elif sub_tag == 'packages':
                    for pkg in m.get('packages', []):
                        if search_term in pkg.get('name', '').lower() or search_term in pkg.get('version', '').lower():
                            found = True; break
                elif sub_tag == 'processes':
                    for proc in m.get('processes', []):
                        if search_term in proc.get('name', '').lower() or search_term in str(proc.get('pid', '')):
                            found = True; break
            
            if found:
                results.append(m)
                added_hostnames.add(hostname)
                
    # --- PESQUISA GLOBAL (SEM TAGS) ---
    else:
        for m in machines:
            hostname = m.get('hostname', '')
            if hostname in added_hostnames: continue
            
            if any(query in str(m.get(k, '')).lower() for k in ['hostname', 'ip_address', 'os_name', 'cpu_name', 'device_status', 'ram_gb']):
                results.append(m)
                added_hostnames.add(hostname)
                continue
            
            found_in_sub = False
            # Redes
            for iface in m.get('netiface', []):
                if query in iface.get('name', '').lower() or query in iface.get('mac', '').lower():
                    found_in_sub = True; break
            if not found_in_sub:
                for addr in m.get('netaddr', []):
                    if query in addr.get('address', '').lower():
                        found_in_sub = True; break
            # Portas e Processos
            if not found_in_sub:
                for port in m.get('ports', []):
                    if query in str(port.get('local', {}).get('port', '')) or query in port.get('process', '').lower():
                        found_in_sub = True; break
            # Pacotes
            if not found_in_sub:
                for pkg in m.get('packages', []):
                    if query in pkg.get('name', '').lower() or query in pkg.get('description', '').lower():
                        found_in_sub = True; break

            if found_in_sub:
                results.append(m)
                added_hostnames.add(hostname)

    return render_template('search.html', results=results, query=query)

@app.route('/machine/<hostname>')
def machine_details(hostname):
    if 'username' not in session:
        return redirect(url_for('login'))
    
    if not hostname.replace('.', '').replace('-', '').isalnum():
        #flash(translate('Nome de host inválido'), 'categoria')
        flash('Nome de host inválido', 'error')
        return redirect(url_for('painel'))
    
    machines = get_cached_machines()
    machine = next((m for m in machines if m.get('hostname') == hostname), None)
    
    if not machine:
        machine = get_machine_fallback(hostname)

    if not machine:
        #flash(translate('Máquina não encontrada'), 'categoria')
        flash('Máquina não encontrada', 'error')
        return redirect(url_for('painel'))
    
    return render_template('machine_details.html', machine=machine)

@app.route('/settings')
def settings():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    machines = get_cached_machines()
    users = []
    if session.get('role') == 'admin':
        users = User.query.all()
    return render_template('settings.html', machines=machines, users=users)

@app.route('/get_data')
def get_data():
    if 'username' not in session:
        return redirect(url_for('login'))

    try:
        import threading
        thread = threading.Thread(target=sync_wazuh_data, args=(app,))
        thread.start()
        app.logger.info("Sincronização iniciada via get_data")
        flash(translate('Sincronização iniciada, aguarde alguns instantes.'), 'success')
        return redirect(url_for('settings'))
    except Exception as e:
        app.logger.error(f"Erro ao iniciar sincronização: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/mfa_status')
def mfa_status():
    if 'username' not in session:
        return jsonify({'error': 'Não autenticado'}), 401
    
    user = User.query.filter_by(username=session['username']).first()
    
    if user:
        return jsonify({
            'enabled': user.mfa_enabled,
            'configured': bool(user.mfa_secret)
        })
    return jsonify({'error': 'Usuário não encontrado'}), 404

@app.route('/toggle_mfa', methods=['POST'])
def toggle_mfa():
    if 'username' not in session:
        return jsonify({'success': False, 'error': 'Não autenticado'}), 401
    
    user = User.query.filter_by(username=session['username']).first()
    
    if not user:
        return jsonify({'success': False, 'error': 'Usuário não encontrado'}), 404
    
    action = request.json.get('action')
    
    if action == 'enable':
        secret = pyotp.random_base32()
        user.mfa_secret = secret
        user.mfa_enabled = False
        
        try:
            db.session.commit()
            totp_uri = pyotp.totp.TOTP(secret).provisioning_uri(
                name=user.username,
                issuer_name="Inventory"
            )
            img = qrcode.make(totp_uri)
            buffered = BytesIO()
            img.save(buffered, format="PNG")
            img_str = base64.b64encode(buffered.getvalue()).decode()
            qr_code = f"data:image/png;base64,{img_str}"
            return jsonify({'success': True, 'qr_code': qr_code, 'secret': secret})
        except Exception as e:
            db.session.rollback()
            app.logger.error(f"Erro ao gerar segredo MFA: {str(e)}")
            return jsonify({'success': False, 'error': 'Erro ao gerar segredo MFA'}), 500
    
    elif action == 'disable':
        user.mfa_enabled = False
        user.mfa_secret = None
        try:
            db.session.commit()
            return jsonify({'success': True})
        except Exception as e:
            db.session.rollback()
            app.logger.error(f"Erro ao desabilitar MFA: {str(e)}")
            return jsonify({'success': False, 'error': 'Erro ao desabilitar MFA'}), 500
    
    return jsonify({'success': False, 'error': 'Ação inválida'}), 400

@app.route('/verify_mfa_setup', methods=['POST'])
def verify_mfa_setup():
    if 'username' not in session:
        return jsonify({'success': False, 'error': 'Não autenticado'}), 401
    
    user = User.query.filter_by(username=session['username']).first()
    if not user:
        return jsonify({'success': False, 'error': 'Usuário não encontrado'}), 404
    
    code = request.json.get('code', '')
    
    totp = pyotp.TOTP(user.mfa_secret)
    if totp.verify(code, valid_window=1):
        user.mfa_enabled = True
        
        try:
            db.session.commit()
            return jsonify({'success': True})
        except Exception as e:
            db.session.rollback()
            app.logger.error(f"Erro ao salvar MFA: {str(e)}")
            return jsonify({'success': False, 'error': 'Erro ao salvar MFA'}), 500
    else:
        return jsonify({'success': False, 'error': 'Código inválido'}), 400

@app.route('/export_pdf')
def export_pdf():
    if 'username' not in session:
        return redirect(url_for('login'))
    
    include_details = request.args.get('include_details', '0') == '1'
    stats = get_cached_stats()
    machines = get_cached_machines()
    
    pdf_buffer = generate_pdf_report(stats, machines, include_details)
    
    response = make_response(pdf_buffer.getvalue())
    response.headers['Content-Type'] = 'application/pdf'
    response.headers['Content-Disposition'] = 'attachment; filename=inventory_report.pdf'
    return response


def translate(key, lang=None):
    if not lang:
        lang = session.get('language', 'pt')
    
    return LANGUAGES.get(lang, {}).get(key, LANGUAGES['pt'].get(key, key))

@app.context_processor
def inject_translations():
    return dict(
        translate=translate,
        language=session.get('language', 'pt')
    )

@app.route('/set_language/<language>')
def set_language(language):
    if language in LANGUAGES:
        session['language'] = language
    return redirect(request.referrer or url_for('dashboard'))

@app.errorhandler(404)
@app.errorhandler(403)
@app.errorhandler(500)
@app.errorhandler(502)
@app.errorhandler(503)
@app.errorhandler(504)
def handle_errors(error):
    code = error.code if hasattr(error, 'code') else 500
    client_ip = request.remote_addr
    username = session.get('username', 'Desconhecido')
    
    error_message = f"Erro {code} - IP: {client_ip}, Usuário: {username}, Endpoint: {request.endpoint}"
    app.logger.error(error_message)
    
    messages = {
        403: "Acesso proibido",
        404: "Página não encontrada",
        500: "Erro interno do servidor",
        502: "Bad Gateway",
        503: "Serviço indisponível",
        504: "Gateway Timeout"
    }
    
    title = messages.get(code, "Erro desconhecido")
    message = f"Ocorreu um erro {code} ao processar sua requisição."
    
    return render_template('error.html', 
                          error_code=code,
                          title=title,
                          message=message,
                          error_details=error_message), code




# Gestão de Máquinas Legadas
@app.route('/settings/legacy_machines')
@admin_required
def legacy_machines():
    legacy_hosts = HostInventory.query.filter_by(is_legacy=True).order_by(HostInventory.hostname).all()
    return render_template('legacy_machines.html', hosts=legacy_hosts)

@app.route('/settings/delete_legacy_host/<int:id>', methods=['POST'])
@admin_required
def delete_legacy_host(id):
    host = HostInventory.query.get_or_404(id)
    if not host.is_legacy:
        return jsonify({'error': 'Apenas máquinas legadas podem ser excluídas por aqui.'}), 400
    
    try:
        db.session.delete(host)
        db.session.commit()
        # Invalida cache para refletir a remoção se necessário (embora o cache principal já filtre legacy)
        if hasattr(app, 'MACHINES_CACHE'):
            app.MACHINES_CACHE['data'] = None
        return jsonify({'success': True, 'message': f'Host {host.hostname} excluído com sucesso.'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    host = os.getenv('HOST', '0.0.0.0')
    port = int(os.getenv('PORT'))
    debug = os.getenv('DEBUG', 'False').lower() == 'true'
    
    print(f" * IPs do servidor: {SERVER_IPS}")
    print(f" * Redes permitidas: {ALLOWED_IP_RANGES}")
    
    app.run(
        debug=debug,
        host=host,
        port=port,
        ssl_context=ssl_context
    )

# --- Conversão do Flask para ASGI (Para o Daphne) ---
asgi_app = WsgiToAsgi(app)
